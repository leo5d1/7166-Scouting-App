package edu.neumont;

public class Entry {
    private String name;
    private String log;

    public String getName() {
        return name;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }

    public Entry(String name, String log) {
        this.name = name;
        this.log = log;
    }
}

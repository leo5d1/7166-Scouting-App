package edu.neumont;

import doyle.lib.IOStream;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;

public class GUI {
// Over-Arching Variables
    static final String DIRECTORY = "src/resources/sheets/";
    String sheetName;
    JTextField scoutName = new JTextField();
    JTextField teamNum = new JTextField();
    JTextField matchNum = new JTextField();
    JTextField alliColor = new JTextField();
    
//Auton Variables
    JLabel autonTag = new JLabel();
    String[] startingPOS= {"", "Red Left", "Red Center", "Red Right","Blue Left", "Blue Center", "Blue Right"};
    JComboBox startPOS = new JComboBox(startingPOS);
    String[] tarmacOpt = {"", "Yes", "No"};
    JComboBox leaveTarmac = new JComboBox(tarmacOpt);
    JTextArea addNotesAU = new JTextArea();
    // Robot Hub Points
    JLabel RUHTotalAU = new JLabel();
    JLabel RUHTagAU = new JLabel();
    int iRUHTotalAU = 0;
    JLabel RLHTotalAU = new JLabel();
    JLabel RLHTagAU = new JLabel();
    int iRLHTotalAU = 0;
    // Human Hub Points
    JLabel HUHTotalAU = new JLabel();
    JLabel HUHTagAU = new JLabel();
    int iHUHTotalAU = 0;
    JLabel HLHTotalAU = new JLabel();
    JLabel HLHTagAU = new JLabel();
    int iHLHTotalAU = 0;
    
// Tele-Op Variables
    JLabel teleopTag = new JLabel();
    String[] climbArray= {"", "No Climb", "Low Rung", "Mid Rung", "High Rung", "Traversal Rung"};
    JComboBox climb = new JComboBox(climbArray);
    JTextArea addNotesTO = new JTextArea();
    // Robot Hub Points
    JLabel RUHTotalTO = new JLabel();
    JLabel RUHTagTO = new JLabel();
    int iRUHTotalTO = 0;
    JLabel RLHTotalTO = new JLabel();
    JLabel RLHTagTO = new JLabel();
    int iRLHTotalTO = 0;
    // Human Hub Points
    JLabel HUHTotalTO = new JLabel();
    JLabel HUHTagTO = new JLabel();
    int iHUHTotalTO = 0;
    JLabel HLHTotalTO = new JLabel();
    JLabel HLHTagTO = new JLabel();
    int iHLHTotalTO = 0;
    
// Points
    // Auton
    int tarmacPoints;
    int RUHAUPoints;
    int RLHAUPoints;
    int HUHAUPoints;
    int HLHAUPoints;
    int autonTotal;
    // Tele-Op
    int climbPoints;
    int RUHTOPoints;
    int RLHTOPoints;
    int HUHTOPoints;
    int HLHTOPoints;
    int teleOpTotal;
    // Total
    int totalPoints;

    public void menu() throws Exception{
        JFrame frame = new JFrame();
        frame.setSize(630, 680);
        frame.setLayout(null);

// Header
        
        // Left Image
        BufferedImage imageL = ImageIO.read(new File("src/resources/images/FRC_Logo.png"));
        JLabel leftImage = new JLabel(new ImageIcon(imageL));
        leftImage.setBounds(5,10, 130, 90);
        frame.add(leftImage);
        
        // Sheet Name
        JLabel sheetName = new JLabel();
        sheetName.setBounds(150, 10, 305, 100);
        sheetName.setText("Scouting Sheet");
        sheetName.setFont(new Font("Serif", Font.PLAIN, 50));
        frame.add(sheetName);
    
        // Right Image
        BufferedImage imageR = ImageIO.read(new File("src/resources/images/FRC_Logo.png"));
        JLabel rightImage = new JLabel(new ImageIcon(imageR));
        rightImage.setBounds(475,10, 130, 90);
        frame.add(rightImage);
        
// Over-arching
        
        // Scouter's Name
        JLabel scoutTag = new JLabel();
        scoutTag.setBounds(90, 110, 100, 30);
        scoutTag.setText("Scouter's Name");
        scoutName.setBounds(90, 145, 100, 30);
        frame.add(scoutTag);
        frame.add(scoutName);
        
        // Team Number
        JLabel teamTag = new JLabel();
        teamTag.setBounds(200, 110, 100, 30);
        teamTag.setText("Team Number");
        teamNum.setBounds(200, 145, 100, 30);
        frame.add(teamTag);
        frame.add(teamNum);

        // Match Number
        JLabel matchTag = new JLabel();
        matchTag.setBounds(310, 110, 100, 30);
        matchTag.setText("Match Number");
        matchNum.setBounds(310, 145, 100, 30);
        frame.add(matchTag);
        frame.add(matchNum);
        
        // Alliance Color
        JLabel alliTag = new JLabel();
        alliTag.setBounds(420, 110, 100, 30);
        alliTag.setText("Alliance Color");
        alliColor.setBounds(420, 145, 100, 30);
        frame.add(alliTag);
        frame.add(alliColor);
        
//Auton
        
        //Auton Tag
        autonTag.setBounds(390, 180, 110, 25);
        autonTag.setFont(new Font("Serif", Font.PLAIN, 20));
        autonTag.setText("Autonomous");
        frame.add(autonTag);
        
        // Start Position
        JLabel startPOSTag = new JLabel();
        startPOSTag.setBounds(310, 210, 115, 25);
        startPOSTag.setText("Start Position");
        startPOS.setBounds(310, 240, 100, 30);
        frame.add(startPOSTag);
        frame.add(startPOS);
        
        // Leave Tarmac
        JLabel leaveTarmacTag = new JLabel();
        leaveTarmacTag.setBounds(450, 210, 115, 25);
        leaveTarmacTag.setText("Leave Tarmac");
        leaveTarmac.setBounds(450, 240, 100, 30);
        frame.add(leaveTarmacTag);
        frame.add(leaveTarmac);
    
        // Robot Upper Hub Total
        JButton subRUHAU = new JButton("-");
        JButton addRUHAU = new JButton("+");
        RUHTagAU.setBounds(310, 275, 140, 25);
        RUHTagAU.setText("Robot Upper Hub Total");
        subRUHAU.setBounds(310, 305, 50, 25);
        addRUHAU.setBounds(385, 305, 50, 25);
        RUHTotalAU.setBounds(365, 305, 15, 25);
        RUHTotalAU.setText(String.valueOf(iRUHTotalAU));
        subRUHAU.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iRUHTotalAU--;
                RUHTotalAU.setText(String.valueOf(iRUHTotalAU));
            }
        });
        addRUHAU.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iRUHTotalAU++;
                RUHTotalAU.setText(String.valueOf(iRUHTotalAU));
            }
        });
        frame.add(subRUHAU);
        frame.add(addRUHAU);
        frame.add(RUHTotalAU);
        frame.add(RUHTagAU);
    
        // Robot Lower Hub Total
        JButton subRLHAU = new JButton("-");
        JButton addRLHAU = new JButton("+");
        RLHTagAU.setBounds(310, 335, 140, 25);
        RLHTagAU.setText("Robot Lower Hub Total");
        subRLHAU.setBounds(310, 365, 50, 25);
        addRLHAU.setBounds(385, 365, 50, 25);
        RLHTotalAU.setBounds(365, 365, 15, 25);
        RLHTotalAU.setText(String.valueOf(iRUHTotalAU));
        subRLHAU.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iRLHTotalAU--;
                RLHTotalAU.setText(String.valueOf(iRLHTotalAU));
            }
        });
        addRLHAU.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iRLHTotalAU++;
                RLHTotalAU.setText(String.valueOf(iRLHTotalAU));
            }
        });
        frame.add(subRLHAU);
        frame.add(addRLHAU);
        frame.add(RLHTotalAU);
        frame.add(RLHTagAU);
    
        // Human Upper Hub Total
        JButton subHUHAU = new JButton("-");
        JButton addHUHAU = new JButton("+");
        HUHTagAU.setBounds(450, 275, 140, 25);
        HUHTagAU.setText("Human Upper Hub Total");
        subHUHAU.setBounds(450, 305, 50, 25);
        addHUHAU.setBounds(525, 305, 50, 25);
        HUHTotalAU.setBounds(505, 305, 15, 25);
        HUHTotalAU.setText(String.valueOf(iHLHTotalAU));
        subHUHAU.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iHUHTotalAU--;
                HUHTotalAU.setText(String.valueOf(iHUHTotalAU));
            }
        });
        addHUHAU.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iHUHTotalAU++;
                HUHTotalAU.setText(String.valueOf(iHUHTotalAU));
            }
        });
        frame.add(subHUHAU);
        frame.add(addHUHAU);
        frame.add(HUHTotalAU);
        frame.add(HUHTagAU);
    
        // Human Lower Hub Total
        JButton subHLHAU = new JButton("-");
        JButton addHLHAU = new JButton("+");
        HLHTagAU.setBounds(450, 335, 140, 25);
        HLHTagAU.setText("Human Lower Hub Total");
        subHLHAU.setBounds(450, 365, 50, 25);
        addHLHAU.setBounds(525, 365, 50, 25);
        HLHTotalAU.setBounds(505, 365, 15, 25);
        HLHTotalAU.setText(String.valueOf(iHUHTotalAU));
        subHLHAU.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iHLHTotalAU--;
                HLHTotalAU.setText(String.valueOf(iHLHTotalAU));
            }
        });
        addHLHAU.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iHLHTotalAU++;
                HLHTotalAU.setText(String.valueOf(iHLHTotalAU));
            }
        });
        frame.add(subHLHAU);
        frame.add(addHLHAU);
        frame.add(HLHTotalAU);
        frame.add(HLHTagAU);
        
        // Additional Notes (Auton)
        JLabel notesTagAU = new JLabel();
        notesTagAU.setBounds(310, 395, 200,25);
        notesTagAU.setText("Additional Notes (Auton)");
        addNotesAU.setBounds(310, 425, 300, 150);
        frame.add(notesTagAU);
        frame.add(addNotesAU);
        
        
// Tele-Op
        
        // Tele-Op Tag
        teleopTag.setBounds(100, 180, 110, 25);
        teleopTag.setFont(new Font("Serif", Font.PLAIN, 20));
        teleopTag.setText("Tele-Op");
        frame.add(teleopTag);
        
        // CLimb
        JLabel climbTag = new JLabel();
        climbTag.setBounds(90, 210, 115, 25);
        climbTag.setText("Climb");
        climb.setBounds(90, 240, 100, 30);
        frame.add(climbTag);
        frame.add(climb);
        
        // Robot Upper Hub Total
        JButton subRUHTO = new JButton("-");
        JButton addRUHTO = new JButton("+");
        RUHTagTO.setBounds(10, 275, 140, 25);
        RUHTagTO.setText("Robot Upper Hub Total");
        subRUHTO.setBounds(10, 305, 50, 25);
        addRUHTO.setBounds(85, 305, 50, 25);
        RUHTotalTO.setBounds(65, 305, 15, 25);
        RUHTotalTO.setText(String.valueOf(iRUHTotalTO));
        subRUHTO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iRUHTotalTO--;
                RUHTotalTO.setText(String.valueOf(iRUHTotalTO));
            }
        });
        addRUHTO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iRUHTotalTO++;
                RUHTotalTO.setText(String.valueOf(iRUHTotalTO));
            }
        });
        frame.add(subRUHTO);
        frame.add(addRUHTO);
        frame.add(RUHTotalTO);
        frame.add(RUHTagTO);

        // Robot Lower Hub Total
        JButton subRLHTO = new JButton("-");
        JButton addRLHTO = new JButton("+");
        RLHTagTO.setBounds(10, 335, 140, 25);
        RLHTagTO.setText("Robot Lower Hub Total");
        subRLHTO.setBounds(10, 365, 50, 25);
        addRLHTO.setBounds(85, 365, 50, 25);
        RLHTotalTO.setBounds(65, 365, 15, 25);
        RLHTotalTO.setText(String.valueOf(iRUHTotalTO));
        subRLHTO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iRLHTotalTO--;
                RLHTotalTO.setText(String.valueOf(iRLHTotalTO));
            }
        });
        addRLHTO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iRLHTotalTO++;
                RLHTotalTO.setText(String.valueOf(iRLHTotalTO));
            }
        });
        frame.add(subRLHTO);
        frame.add(addRLHTO);
        frame.add(RLHTotalTO);
        frame.add(RLHTagTO);
        
        // Human Upper Hub Total
        JButton subHUHTO = new JButton("-");
        JButton addHUHTO = new JButton("+");
        HUHTagTO.setBounds(155, 275, 140, 25);
        HUHTagTO.setText("Human Upper Hub Total");
        subHUHTO.setBounds(155, 305, 50, 25);
        addHUHTO.setBounds(230, 305, 50, 25);
        HUHTotalTO.setBounds(210, 305, 15, 25);
        HUHTotalTO.setText(String.valueOf(iHLHTotalTO));
        subHUHTO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iHUHTotalTO--;
                HUHTotalTO.setText(String.valueOf(iHUHTotalTO));
            }
        });
        addHUHTO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iHUHTotalTO++;
                HUHTotalTO.setText(String.valueOf(iHUHTotalTO));
            }
        });
        frame.add(subHUHTO);
        frame.add(addHUHTO);
        frame.add(HUHTotalTO);
        frame.add(HUHTagTO);
        
        // Human Lower Hub Total
        JButton subHLHTO = new JButton("-");
        JButton addHLHTO = new JButton("+");
        HLHTagTO.setBounds(155, 335, 140, 25);
        HLHTagTO.setText("Human Lower Hub Total");
        subHLHTO.setBounds(155, 365, 50, 25);
        addHLHTO.setBounds(230, 365, 50, 25);
        HLHTotalTO.setBounds(210, 365, 15, 25);
        HLHTotalTO.setText(String.valueOf(iHUHTotalTO));
        subHLHTO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iHLHTotalTO--;
                HLHTotalTO.setText(String.valueOf(iHLHTotalTO));
            }
        });
        addHLHTO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iHLHTotalTO++;
                HLHTotalTO.setText(String.valueOf(iHLHTotalTO));
            }
        });
        frame.add(subHLHTO);
        frame.add(addHLHTO);
        frame.add(HLHTotalTO);
        frame.add(HLHTagTO);
        
        // Additional Notes
        JLabel notesTagTO = new JLabel();
        notesTagTO.setBounds(10, 395, 200,25);
        notesTagTO.setText("Additional Notes (Main Game)");
        addNotesTO.setBounds(10, 425, 290, 150);
        frame.add(notesTagTO);
        frame.add(addNotesTO);
        
// Footer
    
        // Save Sheet
        JButton saveSheet = new JButton("Save");
        saveSheet.setBounds(180,590,120,40);
        saveSheet.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                totalPoints();
                
                Entry entry = createEntry();
            
                try {
                    saveEntry(entry);
                } catch (Exception ex){
                    System.out.println(ex.getMessage());
                }
            }
        });
        frame.add(saveSheet);
        
        // New Sheet
        JButton newSheet = new JButton("New");
        newSheet.setBounds(310,590,120,40);
        newSheet.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clear();
                RUHTotalAU.setText(String.valueOf(iRUHTotalAU));
                RLHTotalAU.setText(String.valueOf(iRLHTotalAU));
                HUHTotalAU.setText(String.valueOf(iHUHTotalAU));
                HLHTotalAU.setText(String.valueOf(iHLHTotalAU));
                RUHTotalTO.setText(String.valueOf(iRUHTotalTO));
                RLHTotalTO.setText(String.valueOf(iRLHTotalTO));
                HUHTotalTO.setText(String.valueOf(iHUHTotalTO));
                HLHTotalTO.setText(String.valueOf(iHLHTotalTO));
            }
        });
        frame.add(newSheet);
        
        frame.setVisible(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
    
    void saveEntry(Entry entry) throws Exception {
        String fileName = DIRECTORY + teamNum.getText() + "-" + matchNum.getText() + ".txt";
        FileOutputStream output = new FileOutputStream(fileName);
        IOStream.writeToStream(entry.getLog(), output);
        output.close();
    }

    Entry createEntry() {
        String name = sheetName;
        
        String log =
                 "Scouter: " + scoutName.getText() +
                 "\nTeam #" + teamNum.getText() +
                 "\nMatch #" + matchNum.getText() +
                 "\nAlliance Color: " + alliColor.getText() +
                 "\n" +
                 "\nAutonomous: " +
                 "\n\tStart Position: " + startPOS.getSelectedItem().toString() +
                 "\n\tLeave Tarmac: " + leaveTarmac.getSelectedItem().toString() +
                 "\n\tRobot Upper Hub Total: " + RUHTotalAU.getText() +
                 "\n\tRobot Lower Hub Total: " + RLHTotalAU.getText() +
                 "\n\tHuman Upper Hub Total: " + HUHTotalAU.getText() +
                 "\n\tHuman Lower Hub Total: " + HLHTotalAU.getText() +
                 "\nAdditional Notes: " +
                 "\n\t" + addNotesAU.getText() +
                 "\n" +
                 "\nTele-Op" +
                 "\n\tRobot Upper Hub Total: " + RUHTotalTO.getText() +
                 "\n\tRobot Lower Hub Total: " + RLHTotalTO.getText() +
                 "\n\tHuman Upper Hub Total: " + HUHTotalTO.getText() +
                 "\n\tHuman Lower Hub Total: " + HLHTotalTO.getText() +
                 "\n\tClimb: " + climb.getSelectedItem().toString() +
                 "\nAdditional Notes: " +
                 "\n\t" + addNotesTO.getText() +
                 "\n\nTotal Points: " +
                 "\n\t" + totalPoints +
                 "\n\nAutonomous Breakdown: " +
                 "\n\tLeave Tarmac: " + tarmacPoints +
                 "\n\tRobot Upper Hub: " + RUHAUPoints +
                 "\n\tRobot Lower Hub: " + RLHAUPoints +
                 "\n\tHuman Upper Hub: " + HUHAUPoints +
                 "\n\tHuman Lower Hub: " + HLHAUPoints +
                 "\n\tAutonomous Total: " + autonTotal +
                 "\nTele-Op Breakdown: " +
                 "\n\tClimb: " + climbPoints +
                 "\n\tRobot Upper Hub: " + RUHTOPoints +
                 "\n\tRobot Lower Hub: " + RLHTOPoints +
                 "\n\tHuman Upper Hub: " + HUHTOPoints +
                 "\n\tHuman Lower Hub: " + HLHTOPoints +
                 "\n\tTele-Op Total: " + teleOpTotal;
        
        Entry entry = new Entry(name, log);

        return entry;
    }
    
    void totalPoints() {
        if (leaveTarmac.getSelectedItem().toString() == "Yes"){
            tarmacPoints = 2;
        } else {
            tarmacPoints = 0;
        }
        RUHAUPoints = Integer.parseInt(RUHTotalAU.getText()) * 4;
        RLHAUPoints = Integer.parseInt(RLHTotalAU.getText()) * 2;
        HUHAUPoints = Integer.parseInt(HUHTotalAU.getText())* 4;
        HLHAUPoints = Integer.parseInt(HLHTotalAU.getText())* 2;
        
        autonTotal = tarmacPoints + RUHAUPoints + RLHAUPoints + HUHAUPoints + HLHAUPoints;
        
        if (climb.getSelectedItem().toString() == "No Climb") {
            climbPoints = 0;
        } else if (climb.getSelectedItem().toString() == "Low Rung") {
            climbPoints = 4;
        } else if (climb.getSelectedItem().toString() == "Mid Rung") {
            climbPoints = 6;
        }else if (climb.getSelectedItem().toString() == "High Rung") {
            climbPoints = 10;
        }else if (climb.getSelectedItem().toString() == "Traversal Rung") {
            climbPoints = 15;
        }
    
        RUHTOPoints = Integer.parseInt(RUHTotalTO.getText()) * 2;
        RLHTOPoints = Integer.parseInt(RLHTotalTO.getText());
        HUHTOPoints = Integer.parseInt(HUHTotalTO.getText()) * 2;
        HLHTOPoints = Integer.parseInt(HLHTotalTO.getText());
        
        teleOpTotal = climbPoints + RUHTOPoints + RLHTOPoints + HUHTOPoints + HLHTOPoints;
        
        totalPoints = autonTotal + teleOpTotal;
    }
    
    void clear() {
        iRUHTotalAU = 0;
        iRLHTotalAU = 0;
        iHUHTotalAU = 0;
        iHLHTotalAU = 0;
        iRUHTotalTO = 0;
        iRLHTotalTO = 0;
        iHUHTotalTO = 0;
        iHLHTotalTO = 0;
        scoutName.setText("");
        teamNum.setText("");
        matchNum.setText("");
        alliColor.setText("");
        addNotesAU.setText("");
        addNotesTO.setText("");
    }
}

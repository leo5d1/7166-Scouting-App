package edu.neumont;



public class Main {

    public static void main(String[] args) {
        GUI gui = new GUI();
        try {
            gui.clear();
            gui.menu();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

    }
    
}

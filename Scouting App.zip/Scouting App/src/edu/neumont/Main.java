package edu.neumont;



public class Main {

    public static void main(String[] args) {
        GUI gui = new GUI();
        try {
            gui.clear();
            gui.menu();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

    }
    /*
    Over-arching:
        Team #
        Match #
        Alliance
        Scouter
        
    
    Auton:
        Start POS
        Leave Tarmac
        RUH total
        RLH total
        HUH total
        HLH total
        Additional Notes

    Tele-Op:
        RUH total
        RLH total
        HUH total
        HLH total
        Climb
            (No, Low, Mid, High, Traverse)
        Additional Notes


     */
}
